const express = require('express');
const path = require('path');
const https = require('https');
const fs = require('fs');

const app = express();
app.use(express.json({ limit: '5mb' })); // Allow large JSON (images encoded in base64)

const DB_FILE = path.join(__dirname, 'database.json');

// API: Simple JSON Database (GET)
app.get('/api/db', (req, res) => {
  if (fs.existsSync(DB_FILE)) {
    res.sendFile(DB_FILE);
  } else {
    res.json(null);
  }
});

// API: Simple JSON Database (POST)
app.post('/api/db', (req, res) => {
  fs.writeFile(DB_FILE, JSON.stringify(req.body), (err) => {
    if (err) return res.status(500).json({ ok: false, error: err.message });
    res.json({ ok: true });
  });
});

// API: Kavenegar SMS Proxy
app.post('/api/sms', (req, res) => {
  console.log('--- SMS Request Received ---');
  const to = req.body && req.body.to;
  const message = req.body && req.body.message;
  const key = process.env.KAVENEGAR_API_KEY;

  console.log('To:', to);
  console.log('API Key First 5 Chars:', key ? key.substring(0, 5) + '...' : 'MISSING!');

  if (!key) {
    console.error('Error: KAVENEGAR_API_KEY is not set in Liara environment variables.');
    return res.status(500).json({ ok: false, error: 'KAVENEGAR_API_KEY is not set' });
  }
  if (!to || !message) {
    console.error('Error: Missing to/message in request body.');
    return res.status(400).json({ ok: false, error: 'to and message are required' });
  }

  const url = `https://api.kavenegar.com/v1/${key}/sms/send.json?receptor=${encodeURIComponent(to)}&message=${encodeURIComponent(message)}`;
  console.log('Calling Kavenegar API...');

  https.get(url, (apiRes) => {
    let data = '';
    apiRes.on('data', chunk => { data += chunk; });
    apiRes.on('end', () => {
      console.log('Kavenegar Response Status:', apiRes.statusCode);
      console.log('Kavenegar Response Body:', data);
      try {
        const parsed = JSON.parse(data);
        res.status(apiRes.statusCode === 200 ? 200 : 502).json({ ok: apiRes.statusCode === 200, data: parsed });
      } catch (e) {
        console.error('Error parsing Kavenegar JSON:', e.message);
        res.status(500).json({ ok: false, error: 'Failed to parse SMS provider response' });
      }
    });
  }).on('error', (e) => {
    console.error('Kavenegar Network Error:', e.message);
    res.status(500).json({ ok: false, error: e.message });
  });
});

// Serve React static files
app.use(express.static(path.join(__dirname, 'dist')));

// Fallback for React Router (Catch-all)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// Listen on Liara's provided port
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(\`Server started successfully on port \${PORT}\`);
});
